# main.py

from extract import load_raw_data
from transform import clean_data
from load import save_to_postgres

def run_etl():
    print("Extracting data...")
    df = load_raw_data()

    print("Transforming data...")
    df_clean = clean_data(df)

    print("Loading data into PostgreSQL...")
    save_to_postgres(df_clean)

    print("ETL process completed successfully.")

if __name__ == "__main__":
    run_etl()
