# LabTest Dataset Cleaning & ETL Pipeline

## Project Overview

This project is part of a Data Engineering & AI take-home assessment. It focuses on cleaning and processing a **messy healthcare dataset** involving cancer diagnostics lab tests. The dataset simulates real-world data issues like:

- Missing values
- Inconsistent formats
- Typos and ambiguous values
- Duplicate records
- Invalid date entries

The goal is to clean and transform the dataset, then load it into a **PostgreSQL database** via a modular ETL pipeline.

---

## Repository Structure


etl_labtests/
├── config.py # Configuration for file paths and DB credentials
├── extract.py # Handles reading raw data from CSV
├── transform.py # Performs data cleaning and standardization
├── load.py # Loads cleaned data into PostgreSQL
├── main.py # Orchestrates the ETL pipeline
├── raw_cleaning_script.py # Python version of the original notebook (for reference)


---

## Dataset

- The dataset is sourced from Kaggle:  
- [Labtest Dataset](https://www.kaggle.com/datasets/eustusmurea/labtest-dataset)

Raw file used:
messy_cancer_lab_dataset.csv

---

## ETL Pipeline Steps

### 1. Extract (`extract.py`)

- Reads the raw dataset from the path defined in `config.py`.
- Validates file existence and loads it into a Pandas DataFrame.

```python
from extract import load_raw_data
df = load_raw_data()
```
### 2. Transform (transform.py)
Cleans the dataset:

Removes duplicates

Converts date columns (creation_date, signout_date)

Standardizes values in categorical fields (e.g., payment_method)

Replaces missing values with "Unknown"

```python
from transform import clean_data
df_clean = clean_data(df)
```
### 3. Load (load.py)
Establishes a connection to PostgreSQL using SQLAlchemy.

Writes the cleaned DataFrame to a table (cleaned_labtests) in the database.

```python
from load import save_to_postgres
save_to_postgres(df_clean)
```
### 4. Run Everything (main.py)
To run the entire pipeline:

```bash
python main.py
```

## Configuration
All pipeline parameters are set in config.py:

```python
RAW_DATA_PATH = "messy_cancer_lab_dataset.csv"
POSTGRES_CONNECTION = "postgresql://username:password@localhost:5432/labtest_db"
OUTPUT_TABLE = "cleaned_labtests"
```
Make sure to replace username, password, and labtest_db with your actual PostgreSQL credentials.

## Cleaning Highlights
- Ensured all date columns are in valid datetime format

Replaced invalid values in payment_method like INS, unknown, credit

Flagged and replaced ambiguous/missing data

Removed full row duplicates

Preserved the cleaned CSV for reuse

## Output
cleaned_labtests.csv (optional export)

cleaned_labtests table in PostgreSQL


## Requirements
- Python 3.7+

- Pandas

- SQLAlchemy

- psycopg2-binary (for PostgreSQL)

## Install dependencies:

```bash
pip install pandas sqlalchemy psycopg2-binary
```

## Final Notes
- This project mimics a real-world healthcare data cleaning task.

- Modular structure ensures the ETL pipeline can be integrated with tools like Airflow.

- Clean code and versioned processing steps promote reproducibility.

## Author
- Josiah Nyamai Munguti