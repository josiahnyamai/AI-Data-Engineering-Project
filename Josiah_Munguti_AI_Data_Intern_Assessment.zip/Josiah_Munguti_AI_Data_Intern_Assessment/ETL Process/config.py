# config.py

# Path to the raw CSV file (you can update this path)
RAW_DATA_PATH = "messy_cancer_lab_dataset.csv"

# PostgreSQL connection string
POSTGRES_CONNECTION = "postgresql://username:password@localhost:5432/labtest_db"

# Output table name
OUTPUT_TABLE = "cleaned_labtests"
