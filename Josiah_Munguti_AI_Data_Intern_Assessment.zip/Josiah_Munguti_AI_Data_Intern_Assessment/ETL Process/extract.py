# extract.py

import pandas as pd
import os
from config import RAW_DATA_PATH

def load_raw_data():
    if not os.path.exists(RAW_DATA_PATH):
        raise FileNotFoundError(f"Raw dataset not found at {RAW_DATA_PATH}")
    return pd.read_csv(RAW_DATA_PATH)
