# transform.py

import pandas as pd

def clean_data(df):
    df = df.copy()

    # Drop duplicates
    df.drop_duplicates(inplace=True)

    # Convert date columns
    for col in ['creation_date', 'signout_date']:
        df[col] = pd.to_datetime(df[col], errors='coerce')

    # Fix known typos
    if 'payment_method' in df.columns:
        df['payment_method'] = df['payment_method'].replace({
            'unknown': 'Unknown',
            'INS': 'Insurance',
            'credit': 'Credit Card'
        })

    # Fill missing values
    df.fillna('Unknown', inplace=True)

    return df
