# load.py

from sqlalchemy import create_engine
from config import POSTGRES_CONNECTION, OUTPUT_TABLE

def save_to_postgres(df):
    engine = create_engine(POSTGRES_CONNECTION)
    with engine.begin() as connection:
        df.to_sql(OUTPUT_TABLE, con=connection, if_exists='replace', index=False)
